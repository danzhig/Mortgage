// DOM Elements
const houseValueInput = document.getElementById('houseValue');
const downPaymentPercentInput = document.getElementById('downPaymentPercent');
const downPaymentAmountInput = document.getElementById('downPaymentAmount');
const interestRateInput = document.getElementById('interestRate');
const termInput = document.getElementById('term');
const extraMonthlyPaymentInput = document.getElementById('extraMonthlyPayment');

// Additional costs elements
const yearlyPropertyTaxInput = document.getElementById('yearlyPropertyTax');
const monthlyUtilitiesInput = document.getElementById('monthlyUtilities');
const monthlyInsuranceInput = document.getElementById('monthlyInsurance');
const monthlyCondoInput = document.getElementById('monthlyCondo');
const totalMonthlyCostSpan = document.getElementById('totalMonthlyCost');

const downPaymentSpan = document.getElementById('downPayment');
const monthlyPaymentSpan = document.getElementById('monthlyPayment');
const totalPrincipalSpan = document.getElementById('totalPrincipal');
const totalInterestSpan = document.getElementById('totalInterest');
const totalPrepaymentsSpan = document.getElementById('totalPrepayments');
const totalExtraPaymentsSpan = document.getElementById('totalExtraPayments');
const loanTermSpan = document.getElementById('loanTerm');

const scheduleTableBody = document.getElementById('scheduleTableBody');
const prepaymentInputs = document.getElementById('prepaymentInputs');

// Track which input was last modified to prevent circular updates
let lastModifiedInput = '';

// Debounce function to prevent calculation on every keystroke
function debounce(func, wait) {
  let timeout;
  return function(...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => {
      func.apply(this, args);
    }, wait);
  };
}

// Debounced version of calculate
const debouncedCalculate = debounce(calculate, 500); // 500ms delay

// Helper to remove formatting and non-numeric characters
function unformatCurrency(value) {
  return value.replace(/[^0-9.]/g, '');
}

// Format number as currency (e.g. "$10,000")
function formatCurrency(value) {
  return '$' + value.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// Initialize the calculator
function init() {
  // Format initial values for houseValue, downPaymentAmount, and extraMonthlyPayment
  houseValueInput.value = formatCurrency(parseFloat(unformatCurrency(houseValueInput.value)) || 0);
  downPaymentAmountInput.value = formatCurrency(parseFloat(unformatCurrency(downPaymentAmountInput.value)) || 0);
  extraMonthlyPaymentInput.value = formatCurrency(parseFloat(unformatCurrency(extraMonthlyPaymentInput.value)) || 0);
  
  // Format initial values for additional costs
  yearlyPropertyTaxInput.value = formatCurrency(parseFloat(unformatCurrency(yearlyPropertyTaxInput.value)) || 0);
  monthlyUtilitiesInput.value = formatCurrency(parseFloat(unformatCurrency(monthlyUtilitiesInput.value)) || 0);
  monthlyInsuranceInput.value = formatCurrency(parseFloat(unformatCurrency(monthlyInsuranceInput.value)) || 0);
  monthlyCondoInput.value = formatCurrency(parseFloat(unformatCurrency(monthlyCondoInput.value)) || 0);

  // Add focus and blur event listeners for Home Value field
  houseValueInput.addEventListener('focus', function() {
    this.value = unformatCurrency(this.value);
  });
  houseValueInput.addEventListener('blur', function() {
    const num = parseFloat(unformatCurrency(this.value)) || 0;
    this.value = formatCurrency(num);
  });

  // Add focus and blur event listeners for Down Payment Amount field
  downPaymentAmountInput.addEventListener('focus', function() {
    this.value = unformatCurrency(this.value);
  });
  downPaymentAmountInput.addEventListener('blur', function() {
    const num = parseFloat(unformatCurrency(this.value)) || 0;
    this.value = formatCurrency(num);
  });

  // Add focus and blur event listeners for Extra Monthly Payment field
  extraMonthlyPaymentInput.addEventListener('focus', function() {
    this.value = unformatCurrency(this.value);
  });
  extraMonthlyPaymentInput.addEventListener('blur', function() {
    const num = parseFloat(unformatCurrency(this.value)) || 0;
    this.value = formatCurrency(num);
  });
  
  // Add focus and blur event listeners for Yearly Property Tax field
  yearlyPropertyTaxInput.addEventListener('focus', function() {
    this.value = unformatCurrency(this.value);
  });
  yearlyPropertyTaxInput.addEventListener('blur', function() {
    const num = parseFloat(unformatCurrency(this.value)) || 0;
    this.value = formatCurrency(num);
  });
  
  // Add focus and blur event listeners for Monthly Utilities field
  monthlyUtilitiesInput.addEventListener('focus', function() {
    this.value = unformatCurrency(this.value);
  });
  monthlyUtilitiesInput.addEventListener('blur', function() {
    const num = parseFloat(unformatCurrency(this.value)) || 0;
    this.value = formatCurrency(num);
  });
  
  // Add focus and blur event listeners for Monthly Insurance field
  monthlyInsuranceInput.addEventListener('focus', function() {
    this.value = unformatCurrency(this.value);
  });
  monthlyInsuranceInput.addEventListener('blur', function() {
    const num = parseFloat(unformatCurrency(this.value)) || 0;
    this.value = formatCurrency(num);
  });
  
  // Add focus and blur event listeners for Monthly Condo Fees field
  monthlyCondoInput.addEventListener('focus', function() {
    this.value = unformatCurrency(this.value);
  });
  monthlyCondoInput.addEventListener('blur', function() {
    const num = parseFloat(unformatCurrency(this.value)) || 0;
    this.value = formatCurrency(num);
  });

  // Setup collapsible sections
  const collapsibles = document.getElementsByClassName('collapsible');
  for (let i = 0; i < collapsibles.length; i++) {
    collapsibles[i].addEventListener('click', function() {
      this.classList.toggle('active');
      const content = this.nextElementSibling;
      
      if (content.style.maxHeight) {
        content.style.maxHeight = null;
        this.querySelector('span').textContent = '▼';
      } else {
        // Special handling for sensitivity table to ensure it opens fully
        if (this.id === 'sensitivityTableButton') {
          // Set a much larger max-height for the sensitivity table
          content.style.maxHeight = '2000px';
        } else {
          content.style.maxHeight = content.scrollHeight + 'px';
        }
        this.querySelector('span').textContent = '▲';
      }
    });
  }
  
  // Use debounced calculation for inputs
  houseValueInput.addEventListener('input', function() {
    lastModifiedInput = 'houseValue';
    updateDownPaymentAmount();
    debouncedCalculate();
  });
  
  downPaymentPercentInput.addEventListener('input', function() {
    lastModifiedInput = 'downPaymentPercent';
    updateDownPaymentAmount();
    debouncedCalculate();
  });
  
  downPaymentAmountInput.addEventListener('input', function() {
    lastModifiedInput = 'downPaymentAmount';
    updateDownPaymentPercent();
    debouncedCalculate();
  });
  
  interestRateInput.addEventListener('input', debouncedCalculate);
  termInput.addEventListener('input', function() {
    initPrepayments();
    debouncedCalculate();
  });
  extraMonthlyPaymentInput.addEventListener('input', debouncedCalculate);
  
  // Add event listeners for additional costs
  yearlyPropertyTaxInput.addEventListener('input', calculateTotalMonthlyCost);
  monthlyUtilitiesInput.addEventListener('input', calculateTotalMonthlyCost);
  monthlyInsuranceInput.addEventListener('input', calculateTotalMonthlyCost);
  monthlyCondoInput.addEventListener('input', calculateTotalMonthlyCost);
  
  initPrepayments();
  initSensitivityTable(); // Initialize sensitivity table
  calculate(); // Initial calculation is not debounced
}

// Update down payment amount when percentage or house value changes
function updateDownPaymentAmount() {
  if (lastModifiedInput === 'downPaymentAmount') return;
  
  const houseValue = parseFloat(unformatCurrency(houseValueInput.value)) || 0;
  const downPaymentPercent = parseFloat(downPaymentPercentInput.value) || 0;
  const downPaymentAmount = houseValue * (downPaymentPercent / 100);
  
  downPaymentAmountInput.value = formatCurrency(downPaymentAmount);
}

// Update down payment percentage when amount changes
function updateDownPaymentPercent() {
  if (lastModifiedInput === 'downPaymentPercent') return;
  
  const houseValue = parseFloat(unformatCurrency(houseValueInput.value)) || 0;
  const downPaymentAmount = parseFloat(unformatCurrency(downPaymentAmountInput.value)) || 0;
  
  if (houseValue > 0) {
    const downPaymentPercent = (downPaymentAmount / houseValue) * 100;
    downPaymentPercentInput.value = downPaymentPercent.toFixed(1);
  }
}

// Initialize prepayment inputs with visual formatting for zero values
function initPrepayments() {
  const termYears = parseInt(termInput.value);
  prepaymentInputs.innerHTML = '';
  
  for (let year = 1; year <= termYears; year++) {
    const row = document.createElement('div');
    row.classList.add('prepayment-row');
    
    const yearSpan = document.createElement('span');
    yearSpan.classList.add('prepayment-year');
    yearSpan.textContent = year;
    
    const dollarSign = document.createElement('span');
    dollarSign.classList.add('dollar-sign');
    dollarSign.textContent = '$';
    
    const input = document.createElement('input');
    input.type = 'text'; // Use text type for formatted display
    input.id = `prepayment-${year}`;
    input.value = formatCurrency(0);
    
    // On focus, remove formatting; if value is zero, clear it
    input.addEventListener('focus', function() {
      if (this.value === formatCurrency(0)) {
        this.value = '';
      } else {
        this.value = unformatCurrency(this.value);
      }
    });
    // On blur, reapply formatting (or revert to "$0" if empty)
    input.addEventListener('blur', function() {
      const num = parseFloat(unformatCurrency(this.value));
      this.value = isNaN(num) || num === 0 ? formatCurrency(0) : formatCurrency(num);
    });
    
    // Use debounced calculation on input
    input.addEventListener('input', debouncedCalculate);
    
    row.appendChild(yearSpan);
    row.appendChild(dollarSign);
    row.appendChild(input);
    
    prepaymentInputs.appendChild(row);
  }
}

// Main calculation function
function calculate() {
  const houseValue = parseFloat(unformatCurrency(houseValueInput.value)) || 0;
  const downPaymentAmount = parseFloat(unformatCurrency(downPaymentAmountInput.value)) || 0;
  const interestRate = parseFloat(interestRateInput.value) || 0;
  const termYears = parseInt(termInput.value) || 30;
  const extraMonthlyPayment = parseFloat(unformatCurrency(extraMonthlyPaymentInput.value)) || 0;
  
  const downPayment = downPaymentAmount;
  const loanAmount = houseValue - downPayment;
  
  // Modified to use semi-annual compounding (Canadian standard)
  const annualRate = interestRate / 100;
  const monthlyRate = Math.pow(1 + annualRate/2, 2/12) - 1;
  const termMonths = termYears * 12;
  
  // Scheduled monthly payment per standard amortization (without extra payments)
  const monthlyPayment = (monthlyRate === 0 || termMonths === 0) ? 
    loanAmount / termMonths : 
    loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, termMonths)) / (Math.pow(1 + monthlyRate, termMonths) - 1);
  
  const prepayments = [];
  let totalPrepayments = 0;
  for (let year = 1; year <= termYears; year++) {
    const input = document.getElementById(`prepayment-${year}`);
    if (input) {
      const rawValue = input.value ? unformatCurrency(input.value) : '0';
      const amount = parseFloat(rawValue) || 0;
      prepayments.push(amount);
      totalPrepayments += amount;
    } else {
      prepayments.push(0);
    }
  }
  
  // Calculate amortization schedule with extra monthly payments included
  const schedule = calculateAmortizationSchedule(loanAmount, monthlyRate, termMonths, monthlyPayment, extraMonthlyPayment, prepayments);
  
  // Sum total extra payments from schedule data
  let totalExtraPayments = 0;
  schedule.yearlyData.forEach(data => {
    totalExtraPayments += data.extra;
  });
  
  updateSummary(downPayment, monthlyPayment, loanAmount, schedule.totalInterest, totalPrepayments, totalExtraPayments, schedule.months / 12);
  updateScheduleTable(schedule.yearlyData);
  renderMortgageChart(schedule.yearlyData, prepayments);
  renderRemainingMortgageChart(schedule.yearlyData, prepayments);
  
  // Update sensitivity table if it's visible
  const sensitivitySection = document.getElementById('sensitivityTableButton');
  if (sensitivitySection && sensitivitySection.classList.contains('active')) {
    createSensitivityTable();
  }
}
// Amortization schedule calculation (incorporating extra monthly payments)
function calculateAmortizationSchedule(loanAmount, monthlyRate, termMonths, monthlyPayment, extraMonthlyPayment, prepayments) {
  let balance = loanAmount;
  let totalInterest = 0;
  let month = 0;
  const yearlyData = [];
  let yearlyPrincipal = 0;
  let yearlyInterest = 0;
  let yearlyPrepayment = 0;
  let yearlyExtra = 0;

  while (balance > 0 && month < termMonths) {
    const currentYear = Math.floor(month / 12) + 1;
    // Calculate interest on current balance
    const interest = balance * monthlyRate;

    // Apply lump-sum prepayment at the start of each year if specified
    if (month % 12 === 0 && prepayments[currentYear - 1] > 0) {
      const lumpPrepayment = prepayments[currentYear - 1];
      yearlyPrepayment = lumpPrepayment;
      balance -= lumpPrepayment;
      if (balance < 0) balance = 0;
    }
    
    // Calculate scheduled principal from standard monthly payment
    let scheduledPrincipal = monthlyPayment - interest;
    if (scheduledPrincipal < 0) scheduledPrincipal = 0;
    
    // Extra principal is the fixed extra monthly payment, adjusted if total exceeds remaining balance
    let extraPrincipal = extraMonthlyPayment;
    if (scheduledPrincipal + extraPrincipal > balance) {
      extraPrincipal = balance - scheduledPrincipal;
      if (extraPrincipal < 0) extraPrincipal = 0;
    }
    
    const totalPrincipalPayment = scheduledPrincipal + extraPrincipal;
    
    yearlyInterest += interest;
    yearlyPrincipal += scheduledPrincipal;
    yearlyExtra += extraPrincipal;
    totalInterest += interest;
    
    if (totalPrincipalPayment > balance) {
      balance = 0;
    } else {
      balance -= totalPrincipalPayment;
    }
    
    // FIX: Treat very small balances as zero to avoid floating point issues
    if (balance < 1) {
      balance = 0;
    }
    
    // At the end of each year or if loan is paid off, store the yearly data
    if ((month + 1) % 12 === 0 || balance === 0 || month === termMonths - 1) {
      yearlyData.push({
        year: currentYear,
        principal: yearlyPrincipal,
        interest: yearlyInterest,
        prepayment: yearlyPrepayment,
        extra: yearlyExtra,
        balance: balance
      });
      yearlyPrincipal = 0;
      yearlyInterest = 0;
      yearlyPrepayment = 0;
      yearlyExtra = 0;
    }
    
    month++;
    if (balance <= 0) break;
  }

  return {
    totalInterest: totalInterest,
    months: month,
    yearlyData: yearlyData
  };
}

// Update summary values on the page
function updateSummary(downPayment, monthlyPayment, loanAmount, totalInterest, totalPrepayments, totalExtraPayments, loanTerm) {
  downPaymentSpan.textContent = formatCurrency(downPayment);
  monthlyPaymentSpan.textContent = formatCurrency(monthlyPayment);
  totalPrincipalSpan.textContent = formatCurrency(loanAmount);
  totalInterestSpan.textContent = formatCurrency(totalInterest);
  totalPrepaymentsSpan.textContent = formatCurrency(totalPrepayments);
  totalExtraPaymentsSpan.textContent = formatCurrency(totalExtraPayments);
  loanTermSpan.textContent = loanTerm.toFixed(1) + ' years';
  
  // Update total monthly cost whenever mortgage payment changes
  calculateTotalMonthlyCost();
}

// Calculate total monthly housing cost including property tax, utilities, insurance, and condo fees
function calculateTotalMonthlyCost() {
  const monthlyPayment = parseFloat(unformatCurrency(monthlyPaymentSpan.textContent)) || 0;
  const yearlyPropertyTax = parseFloat(unformatCurrency(yearlyPropertyTaxInput.value)) || 0;
  const monthlyUtilities = parseFloat(unformatCurrency(monthlyUtilitiesInput.value)) || 0;
  const monthlyInsurance = parseFloat(unformatCurrency(monthlyInsuranceInput.value)) || 0;
  const monthlyCondo = parseFloat(unformatCurrency(monthlyCondoInput.value)) || 0;
  
  // Convert yearly property tax to monthly
  const monthlyPropertyTax = yearlyPropertyTax / 12;
  
  // Calculate total monthly housing cost
  const totalMonthlyCost = monthlyPayment + monthlyPropertyTax + monthlyUtilities + monthlyInsurance + monthlyCondo;
  
  // Update the display
  totalMonthlyCostSpan.textContent = formatCurrency(totalMonthlyCost);
}

// Update the payment schedule table
function updateScheduleTable(yearlyData) {
  scheduleTableBody.innerHTML = '';
  
  yearlyData.forEach(data => {
    const row = document.createElement('tr');
    
    const yearCell = document.createElement('td');
    yearCell.textContent = data.year;
    
    const principalCell = document.createElement('td');
    principalCell.textContent = formatCurrency(data.principal);
    
    const interestCell = document.createElement('td');
    interestCell.textContent = formatCurrency(data.interest);
    
    const prepaymentCell = document.createElement('td');
    prepaymentCell.textContent = formatCurrency(data.prepayment);
    
    const extraCell = document.createElement('td');
    extraCell.textContent = formatCurrency(data.extra);
    
    const balanceCell = document.createElement('td');
    balanceCell.textContent = formatCurrency(data.balance);
    
    row.appendChild(yearCell);
    row.appendChild(principalCell);
    row.appendChild(interestCell);
    row.appendChild(prepaymentCell);
    row.appendChild(extraCell);
    row.appendChild(balanceCell);
    
    scheduleTableBody.appendChild(row);
  });
}

// Render the mortgage chart using Chart.js
function renderMortgageChart(yearlyData, prepayments) {
  const chartElement = document.getElementById('mortgageChart');
  chartElement.innerHTML = '';
  
  const canvas = document.createElement('canvas');
  canvas.width = chartElement.offsetWidth;
  canvas.height = chartElement.offsetHeight;
  chartElement.appendChild(canvas);
  
  const activeYears = yearlyData.filter(data => data.principal > 0 || data.interest > 0);
  
  if (activeYears.length === 0) return;
  
  const years = activeYears.map(data => data.year);
  const principalData = activeYears.map(data => data.principal);
  const interestData = activeYears.map(data => data.interest);
  
  // Scatter data for lump-sum prepayments using actual year values
  const prepaymentScatterData = [];
  activeYears.forEach(data => {
    if (data.prepayment > 0) {
      prepaymentScatterData.push({
        x: data.year,
        y: data.prepayment
      });
    }
  });
  
  // Scatter data for extra monthly payments (annual total) using actual year values
  const extraScatterData = [];
  activeYears.forEach(data => {
    if (data.extra > 0) {
      extraScatterData.push({
        x: data.year,
        y: data.extra
      });
    }
  });
  
  new Chart(canvas, {
    data: {
      labels: years,
      datasets: [
        {
          type: 'bar',
          label: 'Principal',
          data: principalData,
          backgroundColor: '#4a90e2',
          borderColor: '#4a90e2',
          borderWidth: 1,
          order: 2
        },
        {
          type: 'bar',
          label: 'Interest',
          data: interestData,
          backgroundColor: '#50c878',
          borderColor: '#50c878',
          borderWidth: 1,
          order: 2
        },
        {
          type: 'scatter',
          label: 'Lump Sum Prepayments',
          data: prepaymentScatterData,
          backgroundColor: '#9370db',
          borderColor: '#9370db',
          borderWidth: 1,
          pointStyle: 'rectRot',
          pointRadius: 8,
          pointHoverRadius: 10,
          order: 1
        },
        {
          type: 'scatter',
          label: 'Extra Monthly Payments',
          data: extraScatterData,
          backgroundColor: '#FFA500',
          borderColor: '#FFA500',
          borderWidth: 1,
          pointStyle: 'diamond',
          pointRadius: 8,
          pointHoverRadius: 10,
          order: 1
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: {
          stacked: true,
          title: {
            display: true,
            text: 'Year'
          },
          grid: {
            drawBorder: false
          },
          border: {
            display: false
          }
        },
        y: {
          stacked: true,
          title: {
            display: true,
            text: 'Yearly Payments'
          },
          ticks: {
            callback: function(value) {
              return '$' + value.toLocaleString();
            }
          },
          grid: {
            drawBorder: false
          },
          border: {
            display: false
          }
        }
      },
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            usePointStyle: true,
            padding: 20
          }
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              let label = context.dataset.label || '';
              if (label) {
                label += ': ';
              }
              if (context.parsed.y !== null) {
                label += '$' + context.parsed.y.toLocaleString();
              }
              return label;
            }
          }
        }
      },
      animation: {
        duration: 500
      }
    }
  });
}

// Render the remaining mortgage and cumulative interest chart
function renderRemainingMortgageChart(yearlyData, prepayments) {
  const chartElement = document.getElementById('remainingMortgageChart');
  chartElement.innerHTML = '';
  
  const canvas = document.createElement('canvas');
  canvas.width = chartElement.offsetWidth;
  canvas.height = chartElement.offsetHeight;
  chartElement.appendChild(canvas);
  
  // Get the full term specified by the user
  const termYears = parseInt(termInput.value) || 30;
  
  // Create an array of all years from 1 to term length
  const allYears = Array.from({length: termYears}, (_, i) => i + 1);
  
  const activeYears = yearlyData.filter(data => data.principal > 0 || data.interest > 0);
  
  if (activeYears.length === 0) return;
  
  // Create full arrays for balance and cumulative interest
  let balanceData = new Array(termYears).fill(0);
  let cumulativeInterestData = new Array(termYears).fill(0);
  
  // Fill in the actual data we have
  let cumulativeInterest = 0;
  for (const data of activeYears) {
    if (data.year <= termYears) {
      // FIX: Treat very small balances as zero to avoid the flat line issue
      balanceData[data.year - 1] = data.balance < 1 ? 0 : data.balance;
      cumulativeInterest += data.interest;
      cumulativeInterestData[data.year - 1] = cumulativeInterest;
    }
  }
  
  // Fill in missing data (for years after last active year)
  const lastActiveYearIndex = activeYears[activeYears.length - 1].year - 1;
  
  // If the mortgage is paid off early, show zero balance for remaining years
  for (let i = lastActiveYearIndex + 1; i < termYears; i++) {
    balanceData[i] = 0;
    cumulativeInterestData[i] = cumulativeInterest;  // Interest remains constant after payoff
  }
  
  // Check if there are any prepayments or extra monthly payments
  const hasExtraPayments = prepayments.some(p => p > 0) || 
                          parseFloat(unformatCurrency(extraMonthlyPaymentInput.value)) > 0;
  
  // If there are extra payments, calculate the original amortization schedule without extra payments
  let originalBalanceData = new Array(termYears).fill(0);
  let originalCumulativeInterestData = new Array(termYears).fill(0);
  
  if (hasExtraPayments) {
    const houseValue = parseFloat(unformatCurrency(houseValueInput.value)) || 0;
    const downPaymentAmount = parseFloat(unformatCurrency(downPaymentAmountInput.value)) || 0;
    const interestRate = parseFloat(interestRateInput.value) || 0;
    
    const loanAmount = houseValue - downPaymentAmount;
    const annualRate = interestRate / 100;
    const monthlyRate = Math.pow(1 + annualRate/2, 2/12) - 1;
    const termMonths = termYears * 12;
    
    // Calculate standard monthly payment
    const monthlyPayment = (monthlyRate === 0 || termMonths === 0) ? 
      loanAmount / termMonths : 
      loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, termMonths)) / (Math.pow(1 + monthlyRate, termMonths) - 1);
    
    // Calculate original schedule without extra payments
    const emptyPrepayments = new Array(termYears).fill(0);
    const originalSchedule = calculateAmortizationSchedule(loanAmount, monthlyRate, termMonths, monthlyPayment, 0, emptyPrepayments);
    
    // Calculate the balance for each month of a standard amortization schedule 
    // directly rather than relying on the yearly data from calculateAmortizationSchedule
    let balance = loanAmount;
    let monthlyInterest = 0;
    let cumulativeOrigInterest = 0;
    
    // This is a critical fix: we need to calculate data for all years, not just active ones
    for (let year = 1; year <= termYears; year++) {
      // For the final year, ensure balance reaches zero
      if (year === termYears) {
        originalBalanceData[year - 1] = 0;
        
        // For final year, calculate the remaining interest that would be paid
        // This is an estimate based on the previous balance and interest rate
        const remainingInterest = originalBalanceData[year - 2] * monthlyRate * 12;
        cumulativeOrigInterest += remainingInterest;
        originalCumulativeInterestData[year - 1] = cumulativeOrigInterest;
        continue;
      }
      
      // Find data for this year if it exists
      const yearData = originalSchedule.yearlyData.find(data => data.year === year);
      
      if (yearData) {
        // If we have data for this year, use it
        originalBalanceData[year - 1] = yearData.balance < 1 ? 0 : yearData.balance;
        cumulativeOrigInterest += yearData.interest;
        originalCumulativeInterestData[year - 1] = cumulativeOrigInterest;
      } else {
        // For missing years, we need to calculate approximately
        // This should generally not happen with standard amortization unless the loan ends early
        
        // If we're past the last year with data, balance stays at 0
        if (year > originalSchedule.yearlyData[originalSchedule.yearlyData.length - 1].year) {
          originalBalanceData[year - 1] = 0;
          originalCumulativeInterestData[year - 1] = cumulativeOrigInterest;
        } else {
          // Calculate using standard amortization for intermediate missing years
          // This is a simplified calculation for the sake of the chart
          const remainingMonths = (termYears - year + 1) * 12;
          const approxPayment = loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, remainingMonths)) / 
                               (Math.pow(1 + monthlyRate, remainingMonths) - 1);
          const yearlyInterest = balance * monthlyRate * 12;
          const yearlyPrincipal = approxPayment * 12 - yearlyInterest;
          
          balance -= yearlyPrincipal;
          if (balance < 0) balance = 0;
          
          originalBalanceData[year - 1] = balance;
          cumulativeOrigInterest += yearlyInterest;
          originalCumulativeInterestData[year - 1] = cumulativeOrigInterest;
        }
      }
    }
    
    // Force the original balance at the final year to be zero
    originalBalanceData[termYears - 1] = 0;
  }
  
  // Create dataset configuration
  const datasets = [];
  
  if (hasExtraPayments) {
    // Original remaining mortgage (darker blue)
    datasets.push({
      label: 'Original Remaining Mortgage',
      data: originalBalanceData,
      borderColor: '#0d47a1', // Darker blue
      backgroundColor: 'rgba(0, 0, 0, 0)', // Transparent
      borderWidth: 2,
      borderDash: [5, 5], // Dashed line
      fill: false,
      tension: 0.1,
      pointRadius: 0,
      pointHoverRadius: 3
    });
    
    // New remaining mortgage (lighter blue)
    datasets.push({
      label: 'Remaining Mortgage',
      data: balanceData,
      borderColor: '#4a90e2', // Lighter blue
      backgroundColor: 'rgba(74, 144, 226, 0.3)', // Shaded area between lines
      borderWidth: 2,
      fill: '-1', // Fill to the dataset above (original remaining mortgage)
      tension: 0.1,
      pointRadius: 2,
      pointHoverRadius: 4
    });
    
    // Original cumulative interest (darker green)
    datasets.push({
      label: 'Original Cumulative Interest',
      data: originalCumulativeInterestData,
      borderColor: '#2e7d32', // Darker green
      backgroundColor: 'rgba(0, 0, 0, 0)', // Transparent
      borderWidth: 2,
      borderDash: [5, 5], // Dashed line
      fill: false,
      tension: 0.1,
      pointRadius: 0,
      pointHoverRadius: 3
    });
    
    // New cumulative interest (lighter green)
    datasets.push({
      label: 'Cumulative Interest',
      data: cumulativeInterestData,
      borderColor: '#50c878', // Lighter green
      backgroundColor: 'rgba(80, 200, 120, 0.3)', // Shaded area between lines
      borderWidth: 2,
      fill: '-1', // Fill to the dataset above (original cumulative interest)
      tension: 0.1,
      pointRadius: 2,
      pointHoverRadius: 4
    });
  } else {
    // Regular display without comparison (original implementation)
    datasets.push({
      label: 'Remaining Mortgage',
      data: balanceData,
      borderColor: '#4a90e2',
      backgroundColor: 'rgba(74, 144, 226, 0.1)',
      fill: true,
      tension: 0.1,
      pointRadius: 3,
      pointHoverRadius: 5
    });
    
    datasets.push({
      label: 'Cumulative Interest',
      data: cumulativeInterestData,
      borderColor: '#50c878',
      backgroundColor: 'rgba(80, 200, 120, 0.1)',
      fill: true,
      tension: 0.1,
      pointRadius: 3,
      pointHoverRadius: 5
    });
  }
  
  new Chart(canvas, {
    type: 'line',
    data: {
      labels: allYears,  // Use all years for x-axis
      datasets: datasets
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: {
          title: {
            display: true,
            text: 'Year'
          },
          grid: {
            drawBorder: false
          },
          border: {
            display: false
          }
        },
        y: {
          title: {
            display: true,
            text: 'Amount'
          },
          ticks: {
            callback: function(value) {
              return '$' + value.toLocaleString();
            }
          },
          grid: {
            drawBorder: false
          },
          border: {
            display: false
          }
        }
      },
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            usePointStyle: true,
            padding: 20
          }
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              let label = context.dataset.label || '';
              if (label) {
                label += ': ';
              }
              if (context.parsed.y !== null) {
                label += '$' + context.parsed.y.toLocaleString();
              }
              return label;
            },
            footer: function(tooltipItems) {
              // Only show comparison for pairs of lines
              if (hasExtraPayments && tooltipItems.length >= 2) {
                const originalValue = tooltipItems[0].parsed.y;
                const newValue = tooltipItems[1].parsed.y;
                
                if (tooltipItems[0].datasetIndex === 0 && tooltipItems[1].datasetIndex === 1) {
                  // Mortgage reduction
                  const difference = originalValue - newValue;
                  return 'Mortgage reduction: $' + difference.toLocaleString();
                } else if (tooltipItems[0].datasetIndex === 2 && tooltipItems[1].datasetIndex === 3) {
                  // Interest savings
                  const difference = originalValue - newValue;
                  return 'Interest savings: $' + difference.toLocaleString();
                }
              }
              return '';
            }
          }
        }
      },
      animation: {
        duration: 500
      }
    }
  });
}

// Create and render the sensitivity table
function createSensitivityTable() {
  const sensitivityTableBody = document.getElementById('sensitivityTableBody');
  if (!sensitivityTableBody) return;
  
  // Clear previous table content
  sensitivityTableBody.innerHTML = '';
  
  // Get current values
  const houseValue = parseFloat(unformatCurrency(houseValueInput.value)) || 0;
  const currentDownPaymentPercent = parseFloat(downPaymentPercentInput.value) || 20;
  const currentInterestRate = parseFloat(interestRateInput.value) || 5;
  const termYears = parseInt(termInput.value) || 30;
  
  // Calculate ranges
  // For down payment percentage: 5 steps down and 5 steps up, but minimum 5%
  const downPaymentMin = Math.max(5, currentDownPaymentPercent - 10);
  let downPaymentValues = [];
  for (let i = 0; i < 11; i++) {
    const value = downPaymentMin + (i * 2);
    downPaymentValues.push(value);
  }
  
  // For interest rate: 5 steps down and 5 steps up in 0.1% increments
  const interestRateMin = Math.max(0.1, currentInterestRate - 0.5);
  let interestRateValues = [];
  for (let i = 0; i < 11; i++) {
    const value = (interestRateMin + (i * 0.1)).toFixed(1);
    interestRateValues.push(parseFloat(value));
  }
  
  // Create header row with interest rates
  const headerRow = document.createElement('tr');
  const cornerCell = document.createElement('th');
  cornerCell.textContent = 'Down Payment % \\ Interest Rate %';
  cornerCell.classList.add('corner-cell');
  headerRow.appendChild(cornerCell);
  
  interestRateValues.forEach(rate => {
    const th = document.createElement('th');
    th.textContent = rate.toFixed(1) + '%';
    
    // Highlight the current interest rate
    if (Math.abs(rate - currentInterestRate) < 0.05) {
      th.classList.add('current-value');
    }
    
    headerRow.appendChild(th);
  });
  
  sensitivityTableBody.appendChild(headerRow);
  
  // Create rows for each down payment percentage
  downPaymentValues.forEach(downPaymentPercent => {
    const row = document.createElement('tr');
    
    // Add row header (down payment percentage)
    const rowHeader = document.createElement('th');
    rowHeader.textContent = downPaymentPercent.toFixed(1) + '%';
    
    // Highlight the current down payment percentage
    if (Math.abs(downPaymentPercent - currentDownPaymentPercent) < 1) {
      rowHeader.classList.add('current-value');
    }
    
    row.appendChild(rowHeader);
    
    // Calculate payment for each interest rate with this down payment
    interestRateValues.forEach(interestRate => {
      const td = document.createElement('td');
      
      // Calculate loan amount based on down payment percentage
      const downPaymentAmount = houseValue * (downPaymentPercent / 100);
      const loanAmount = houseValue - downPaymentAmount;
      
      // Calculate monthly payment
      const annualRate = interestRate / 100;
      const monthlyRate = Math.pow(1 + annualRate/2, 2/12) - 1;
      const termMonths = termYears * 12;
      
      let monthlyPayment = 0;
      if (monthlyRate === 0 || termMonths === 0) {
        monthlyPayment = loanAmount / termMonths;
      } else {
        monthlyPayment = loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, termMonths)) / (Math.pow(1 + monthlyRate, termMonths) - 1);
      }
      
      td.textContent = formatCurrency(monthlyPayment);
      
      // Highlight the current values combination
      if (Math.abs(downPaymentPercent - currentDownPaymentPercent) < 1 && 
          Math.abs(interestRate - currentInterestRate) < 0.05) {
        td.classList.add('current-cell');
      }
      
      row.appendChild(td);
    });
    
    sensitivityTableBody.appendChild(row);
  });
}

// Initialize sensitivity table
function initSensitivityTable() {
  // Create the sensitivity table when its section is opened
  const sensitivityButton = document.getElementById('sensitivityTableButton');
  if (sensitivityButton) {
    sensitivityButton.addEventListener('click', function() {
      if (this.classList.contains('active')) {
        createSensitivityTable();
      }
    });
  }
}

document.addEventListener('DOMContentLoaded', init);